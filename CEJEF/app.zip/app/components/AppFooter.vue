<template>
    <footer>
        <p>© 2024 CEJEF. All rights reserved.</p>
    </footer>
</template>