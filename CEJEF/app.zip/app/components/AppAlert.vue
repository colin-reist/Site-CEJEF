<template>
  <span>
    <slot />
  </span>
</template>
