<template>
	<a href="/" class="inline-flex" aria-label="Accueil CEJEF">
		<img src="../assets/img/DSSAc.png" alt="Logo CEJEF" class="h-full w-auto max-h-full object-contain"/>
	</a>
</template>
