<template>
    <section>
        <p>formations</p>
    </section>
</template>