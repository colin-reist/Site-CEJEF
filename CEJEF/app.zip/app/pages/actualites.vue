<template>
    <section>
        <p>Bienvenue sur la page Campus du CEJEF.</p>
    </section>
</template>