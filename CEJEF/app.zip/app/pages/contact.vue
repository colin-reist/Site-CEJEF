<template>
    <section>
        <p>Contactez-nous via cette page.</p>
    </section>
</template>