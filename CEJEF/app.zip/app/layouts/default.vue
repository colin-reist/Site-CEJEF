<template>
  <div>
    <AppHeader />
    <slot />
    <AppFooter />
  </div>
</template>
